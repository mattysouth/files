$(document).scroll(function() {
    var y = $(this).scrollTop();
    if (y >= 0 && y <= 100) {
        $('.nav').fadeIn();
    } else {
        $('.nav').fadeOut();
    }

});

/* $(function() {
    $('.yeoido_A').hover(function() {
        $('.yeoido_A_desc').fadeIn();
    }, function() {
        $('.yeoido_A_desc').fadeOut();
    });
});

$(function() {
    $('.yeoido_B').hover(function() {
        $('.yeoido_B_desc').fadeIn();
    }, function() {
        $('.yeoido_B_desc').fadeOut();
    });
});

$(function() {
    $('.yeoido_C').hover(function() {
        $('.yeoido_C_desc').fadeIn();
    }, function() {
        $('.yeoido_C_desc').fadeOut();
    });
});

$(function() {
    $('.yeoido_D').hover(function() {
        $('.yeoido_D_desc').fadeIn();
    }, function() {
        $('.yeoido_D_desc').fadeOut();
    });
});

$(function() {
    $('.yeoido_E').hover(function() {
        $('.yeoido_E_desc').fadeIn();
    }, function() {
        $('.yeoido_E_desc').fadeOut();
    });
});

$(function() {
    $('.yeoido_F').hover(function() {
        $('.yeoido_F_desc').fadeIn();
    }, function() {
        $('.yeoido_F_desc').fadeOut();
    });
});
*/
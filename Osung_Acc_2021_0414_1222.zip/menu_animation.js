$(document).ready(function() {
    $("html,body").scrollTop(55);
});
/* $('.hamburger').click(function() {
    $('#menuToggle').css({
        'z-index': '99',
    });
    $('#menuToggle input ').css({
        'z-index': '99',
    });
});*/
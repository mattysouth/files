$(document).scroll(function() {
    var y = $(this).scrollTop();

    if (y >= 0 && y <= 400) {
        $('.intro').fadeIn();
    } else {
        $('.intro').fadeOut();
    }
    if (y >= 410 && y <= 800) {
        $('.greeting').fadeIn();
    } else {
        $('.greeting').fadeOut();

    }
    if (y >= 810 && y <= 1200) {
        $('.service').fadeIn();
        $('.service').css('display', 'flex');
    } else {
        $('.service').fadeOut();
    }
    if (y >= 1210 && y <= 1600) {
        $('.location').fadeIn();
    } else {
        $('.location').fadeOut();
    }

});